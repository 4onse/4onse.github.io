#ifndef INTERRUPT_H
#define INTERRUPT_H

#include "Arduino.h"

void rainIRQ();

void wspeedIRQ();

#endif
